/**
 * Firebase Cloud Functions — the ONLY trusted place role changes happen.
 * Deploy with: firebase deploy --only functions
 *
 * Why this exists: firestore.rules can block a client from *writing* role: "ADMIN", but
 * something still has to grant that role to the real owner in the first place. Doing that
 * from a Cloud Function (which runs with the Admin SDK, not the user's own credentials) means
 * the promotion logic never has to trust anything the client app sends.
 */
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

// Set this via `firebase functions:config:set admin.master_email="you@yourdomain.com"`
// or (2nd gen) an environment variable — do NOT hardcode secrets in source control.
const MASTER_ADMIN_EMAIL = functions.config().admin?.master_email || "owner@yourdomain.com";

/**
 * Runs automatically whenever a new Firebase Auth user is created.
 * If (and only if) their verified email matches MASTER_ADMIN_EMAIL, promote them to ADMIN
 * with unlimited access. Every other new user is left as the default USER role that
 * AuthRepository.bootstrapNewUser already wrote to Firestore.
 */
exports.autoPromoteMasterAdmin = functions.auth.user().onCreate(async (user) => {
  if (!user.email || user.email.toLowerCase() !== MASTER_ADMIN_EMAIL.toLowerCase()) {
    return null;
  }
  if (!user.emailVerified) {
    console.warn(`Master admin email ${user.email} not yet verified; skipping auto-promotion.`);
    return null;
  }

  const userRef = admin.firestore().collection("users").doc(user.uid);
  await userRef.set(
    {
      uid: user.uid,
      email: user.email,
      role: "ADMIN",
      hasUnlimitedAccess: true,
      creditBalance: 0,
      subscriptionTier: "UNLIMITED",
    },
    { merge: true }
  );
  console.log(`Promoted ${user.email} to ADMIN.`);
  return null;
});

/**
 * Callable function letting an EXISTING admin promote/demote another user's role.
 * This is the mechanism the Admin Panel should call instead of ever writing
 * `role` directly from the client SDK.
 */
exports.setUserRole = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Must be signed in.");
  }
  const callerSnap = await admin.firestore().collection("users").doc(context.auth.uid).get();
  if (callerSnap.data()?.role !== "ADMIN") {
    throw new functions.https.HttpsError("permission-denied", "Only admins can change roles.");
  }

  const { targetUid, newRole } = data;
  if (!["USER", "ADMIN"].includes(newRole)) {
    throw new functions.https.HttpsError("invalid-argument", "newRole must be USER or ADMIN.");
  }

  await admin.firestore().collection("users").doc(targetUid).update({
    role: newRole,
    hasUnlimitedAccess: newRole === "ADMIN",
  });
  return { success: true };
});

/**
 * Optional: verify a Google Play purchase token server-side (recommended over trusting the
 * client's own "purchase succeeded, please add credits" call in BillingManager.kt) before
 * crediting the user's balance. Requires the Play Developer API + a service account with
 * "View financial data" access; wire this up before launch if IAP revenue matters.
 */
exports.verifyAndGrantPlayPurchase = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Must be signed in.");
  }
  // TODO: call androidpublisher.purchases.products.get with data.purchaseToken + data.sku,
  // confirm purchaseState === 0 (purchased) and not already processed, THEN:
  // await admin.firestore().collection("users").doc(context.auth.uid)
  //   .update({ creditBalance: admin.firestore.FieldValue.increment(creditAmountForSku) });
  throw new functions.https.HttpsError("unimplemented", "Wire up Play Developer API verification here.");
});
