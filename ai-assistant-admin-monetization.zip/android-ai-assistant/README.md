# AI Assistant — Admin/User Panel + Monetization Module

Drop-in module implementing RBAC, credit-based monetization, and Google Play billing on top of
an existing (forked) Compose AI-assistant app.

## File map

```
app/src/main/java/com/aiassistant/app/
├── model/User.kt                    # AppUser, UserRole, ApiKeyConfig, CreditTransaction
├── data/
│   ├── AuthRepository.kt            # sign-in/register, new-user bootstrap (welcome credits)
│   └── FirestoreRepository.kt       # credit deduction (transactional), admin queries, API config
├── viewmodel/
│   ├── AuthViewModel.kt             # session state -> Compose UI
│   ├── CreditViewModel.kt           # gatekeeps every AI call through the credit check
│   └── AdminViewModel.kt            # dashboard: user list, balance edits, API config
├── billing/BillingManager.kt        # Google Play Billing v7 (consumables + subscriptions)
└── ui/
    ├── AppNavigation.kt             # route-level ADMIN gate (defense in depth)
    └── screens/
        ├── SettingsScreen.kt        # branches on UserRole.USER vs ADMIN
        ├── AdminPanelScreen.kt      # user management + global API key config
        └── PaywallScreen.kt         # shown when credits hit 0

firebase/
├── firestore.rules                  # THE real enforcement layer for RBAC
└── functions/index.js               # master-admin auto-promotion, role changes, IAP verification
```

## Setup steps

1. **Firebase project**: enable Authentication (Email/Password, optionally Google), Firestore,
   and Cloud Functions.
2. **Set your master admin email** in two places (must match):
   - `firebase functions:config:set admin.master_email="you@yourdomain.com"`
   - `AdminConfig.MASTER_ADMIN_EMAIL` in `AuthRepository.kt` (UI hint only, not the real gate)
3. **Deploy rules & functions**:
   ```
   firebase deploy --only firestore:rules,functions
   ```
4. **Create Play Console products**: `credits_50`, `credits_150`, `credits_500` (consumables),
   `pro_monthly`, `unlimited_monthly` (subscriptions).
5. Merge `app/build.gradle.kts.snippet` into your app module's Gradle file.
6. Wire `AppNavigation` into your existing `NavHost`/`Scaffold`, and call
   `CreditViewModel.runAiQuery(...)` around your existing model-call code instead of calling
   the model directly.

## Why the security-critical logic lives where it does (please read before shipping)

- **Role is never client-writable.** `firestore.rules` blocks any client — including the
  legitimate user's own device — from setting `role: "ADMIN"` on their own document. The only
  paths to ADMIN are (a) the `autoPromoteMasterAdmin` Cloud Function triggered by Auth user
  creation, matched against a server-held email, or (b) an existing admin calling the
  `setUserRole` callable function. A hardcoded email check inside the Kotlin app is easily
  defeated by decompiling the APK, so it's used only for UI purposes, never as the actual gate.
- **Credit deduction is a Firestore transaction**, not a plain read-then-write, so two
  concurrent AI requests can't both pass a "balance > 0" check and drive the balance negative.
- **Admins bypass charging entirely** via `AppUser.canUseAiWithoutCharge()`, checked in exactly
  one place (`CreditViewModel`) so the "admins are free" rule can't drift out of sync between
  screens.
- **IAP crediting is currently client-confirmed** for simplicity (`BillingManager.handlePurchase`
  writes to Firestore as soon as Google's `PurchasesUpdatedListener` fires). This is fine to
  prototype with but is spoofable by a modified client. Before you rely on this for real revenue,
  move purchase verification into `verifyAndGrantPlayPurchase` (server-side, via the Play
  Developer API) and have the client only call that function rather than writing credits itself.
- **Global provider API keys** (`config/apiKeys`) are locked to admin-only *read* access in the
  rules. If your current app reads these directly from client Firestore to call Gemini/OpenRouter
  from the device, that's a credential-leak risk independent of these rules — route those calls
  through a backend/Cloud Function proxy instead so the raw keys never reach a user's device.

## Integration notes

- This module assumes your existing app already has an AI-calling layer (e.g. `AiRepository` /
  `ChatViewModel`) that hits Gemini/OpenRouter/Groq/Ollama. Wrap that call site with
  `CreditViewModel.runAiQuery(user, modelUsed, cost) { /* existing model call */ }` rather than
  rewriting the model-calling code — this keeps the credit logic decoupled from prompt/response
  handling.
- `SettingsScreen` takes plain callbacks so you can wire it into whatever navigation/DI pattern
  your existing app already uses instead of assuming Hilt/Koin.
