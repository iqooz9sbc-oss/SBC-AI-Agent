package com.aiassistant.app.model

/**
 * Role is ALWAYS assigned server-side (Cloud Function trigger or manually by an existing admin
 * via the Admin Panel). It is never writable by the client's own UID — see firestore.rules.
 */
enum class UserRole {
    USER,
    ADMIN;

    companion object {
        fun fromString(value: String?): UserRole =
            values().firstOrNull { it.name.equals(value, ignoreCase = true) } ?: USER
    }
}

data class AppUser(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: UserRole = UserRole.USER,
    val creditBalance: Long = 0L,
    val hasUnlimitedAccess: Boolean = false, // true only for ADMIN, set server-side
    val subscriptionTier: String = "FREE",   // FREE, PRO, UNLIMITED
    val subscriptionExpiresAt: Long? = null,
    val personalApiKey: String? = null,      // user's own BYO-key, optional
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = System.currentTimeMillis()
) {
    /** Single source of truth the UI should call — never check role == ADMIN directly in screens. */
    fun canUseAiWithoutCharge(): Boolean = role == UserRole.ADMIN && hasUnlimitedAccess

    fun hasCredits(): Boolean = canUseAiWithoutCharge() || creditBalance > 0
}

data class ApiKeyConfig(
    val geminiKey: String = "",
    val openRouterKey: String = "",
    val groqKey: String = "",
    val ollamaEndpoint: String = "",
    val updatedBy: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

data class CreditTransaction(
    val id: String = "",
    val uid: String = "",
    val amount: Long = 0L,          // negative = deduction, positive = purchase/grant
    val reason: String = "",        // "AI_QUERY", "IAP_PURCHASE", "ADMIN_GRANT", "WELCOME_BONUS"
    val relatedModel: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
