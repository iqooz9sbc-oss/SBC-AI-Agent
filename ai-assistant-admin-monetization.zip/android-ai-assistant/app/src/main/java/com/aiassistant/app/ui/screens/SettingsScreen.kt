package com.aiassistant.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aiassistant.app.model.AppUser
import com.aiassistant.app.model.UserRole

@Composable
fun SettingsScreen(
    user: AppUser,
    onBuyCreditsClick: () -> Unit,
    onUpgradePlanClick: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onSetPersonalApiKey: (String) -> Unit,
    onClearChatHistory: () -> Unit,
    onSignOut: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        ProfileCard(user)

        when (user.role) {
            UserRole.ADMIN -> AdminSettingsSection(user, onOpenAdminPanel)
            UserRole.USER -> UserSettingsSection(
                user = user,
                onBuyCreditsClick = onBuyCreditsClick,
                onUpgradePlanClick = onUpgradePlanClick,
                onSetPersonalApiKey = onSetPersonalApiKey
            )
        }

        Divider()

        Text("Chat History", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(onClick = onClearChatHistory, modifier = Modifier.fillMaxWidth()) {
            Text("Clear Chat History")
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onSignOut,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Sign Out")
        }
    }
}

@Composable
private fun ProfileCard(user: AppUser) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(user.displayName.ifBlank { "Unnamed User" }, fontWeight = FontWeight.Bold)
            Text(user.email, style = MaterialTheme.typography.bodySmall)
            AssistChip(
                onClick = {},
                label = { Text(if (user.role == UserRole.ADMIN) "ADMIN" else user.subscriptionTier) }
            )
        }
    }
}

/** USER role: shows credit balance, paywall entry points, and BYO API key — no admin controls. */
@Composable
private fun UserSettingsSection(
    user: AppUser,
    onBuyCreditsClick: () -> Unit,
    onUpgradePlanClick: () -> Unit,
    onSetPersonalApiKey: (String) -> Unit
) {
    var apiKeyInput by remember { mutableStateOf(user.personalApiKey ?: "") }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Credit Balance", style = MaterialTheme.typography.titleMedium)
                Text("${user.creditBalance}", style = MaterialTheme.typography.headlineSmall)
            }
            Button(onClick = onBuyCreditsClick, modifier = Modifier.fillMaxWidth()) {
                Text("Buy Credits")
            }
            OutlinedButton(onClick = onUpgradePlanClick, modifier = Modifier.fillMaxWidth()) {
                Text(if (user.subscriptionTier == "FREE") "Upgrade Plan" else "Manage Subscription")
            }
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Personal API Key (optional)", style = MaterialTheme.typography.titleMedium)
            Text(
                "Use your own Gemini/OpenRouter key to skip credit deduction on your requests.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(
                onClick = { onSetPersonalApiKey(apiKeyInput) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save Key") }
        }
    }
}

/** ADMIN role: no paywall, unlimited-usage indicator, and entry point into the full Admin Panel. */
@Composable
private fun AdminSettingsSection(user: AppUser, onOpenAdminPanel: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AdminPanelSettings, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Admin Control Center", style = MaterialTheme.typography.titleMedium)
            }
            Text(
                if (user.hasUnlimitedAccess) "Unlimited AI usage: ENABLED"
                else "Unlimited AI usage: disabled",
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = onOpenAdminPanel, modifier = Modifier.fillMaxWidth()) {
                Text("Open Admin Panel")
            }
        }
    }
    // Deliberately no "Buy Credits" / "Upgrade Plan" UI is rendered for ADMIN.
}
