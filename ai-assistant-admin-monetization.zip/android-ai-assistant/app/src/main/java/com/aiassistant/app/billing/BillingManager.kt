package com.aiassistant.app.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import com.aiassistant.app.data.FirestoreRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Google Play Billing Library v6+ wrapper.
 * Products must be created in Play Console > Monetize > Products first:
 *   - In-app products (consumable): credits_50, credits_150, credits_500
 *   - Subscriptions: pro_monthly, unlimited_monthly
 *
 * SECURITY NOTE: crediting the user's Firestore balance directly from the client after
 * onPurchasesUpdated (as done below for simplicity) is convenient but spoofable by a modified
 * APK. For production, verify the purchase token server-side with the Google Play Developer API
 * (via a Cloud Function) BEFORE granting credits, then call `acknowledgePurchase`/`consumeAsync`
 * from that same trusted backend. Treat the client-side path here as a starting point, not
 * the final trust boundary.
 */
class BillingManager(
    private val context: Context,
    private val uid: String,
    private val firestoreRepo: FirestoreRepository = FirestoreRepository(),
    private val onCreditsGranted: (Long) -> Unit = {},
    private val onError: (String) -> Unit = {}
) {
    private val creditValueBySku = mapOf(
        "credits_50" to 50L,
        "credits_150" to 150L,
        "credits_500" to 500L
    )

    private val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            purchases.forEach { handlePurchase(it) }
        } else if (billingResult.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
            onError("Billing error: ${billingResult.debugMessage}")
        }
    }

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(purchasesUpdatedListener)
        .enablePendingPurchases()
        .build()

    fun startConnection(onReady: () -> Unit) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) onReady()
                else onError("Billing setup failed: ${result.debugMessage}")
            }
            override fun onBillingServiceDisconnected() {
                // Implement retry/backoff in production.
            }
        })
    }

    fun launchCreditPurchase(activity: Activity, sku: String) {
        queryAndLaunch(activity, sku, BillingClient.ProductType.INAPP)
    }

    fun launchSubscriptionPurchase(activity: Activity, sku: String) {
        queryAndLaunch(activity, sku, BillingClient.ProductType.SUBS)
    }

    private fun queryAndLaunch(activity: Activity, sku: String, type: String) {
        val product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(sku)
            .setProductType(type)
            .build()
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build()

        billingClient.queryProductDetailsAsync(params) { result, productDetailsList ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK || productDetailsList.isEmpty()) {
                onError("Product not found: $sku")
                return@queryProductDetailsAsync
            }
            val details = productDetailsList[0]
            val offerToken = details.subscriptionOfferDetails?.firstOrNull()?.offerToken

            val productParamsBuilder = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(details)
            if (type == BillingClient.ProductType.SUBS && offerToken != null) {
                productParamsBuilder.setOfferToken(offerToken)
            }

            val flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(productParamsBuilder.build()))
                .build()

            billingClient.launchBillingFlow(activity, flowParams)
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return

        val sku = purchase.products.firstOrNull() ?: return
        val creditAmount = creditValueBySku[sku]

        CoroutineScope(Dispatchers.IO).launch {
            // Acknowledge (required within 3 days or Google auto-refunds the purchase).
            if (!purchase.isAcknowledged) {
                val ackParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                billingClient.acknowledgePurchase(ackParams) { }
            }

            if (creditAmount != null) {
                firestoreRepo.addPurchasedCredits(uid, creditAmount, sku)
                    .onSuccess {
                        // Consumable credit packs must be consumed so they can be bought again.
                        val consumeParams = ConsumeParams.newBuilder()
                            .setPurchaseToken(purchase.purchaseToken)
                            .build()
                        billingClient.consumeAsync(consumeParams) { _, _ -> }
                        onCreditsGranted(creditAmount)
                    }
                    .onFailure { onError(it.message ?: "Failed to grant credits") }
            }
            // Subscription SKUs (pro_monthly, unlimited_monthly): grant tier server-side via
            // Firebase's Play Developer webhook / Cloud Function (RTDN), not shown here — the
            // client should never be the sole writer of subscriptionTier for recurring plans.
        }
    }

    fun endConnection() = billingClient.endConnection()
}
