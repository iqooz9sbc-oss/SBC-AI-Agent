package com.aiassistant.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiassistant.app.data.FirestoreRepository
import com.aiassistant.app.model.AppUser
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AiQueryEvent {
    object ShowPaywall : AiQueryEvent()
    data class Error(val message: String) : AiQueryEvent()
}

/**
 * Wraps every AI call so the credit rule is enforced in exactly one place:
 *   1. Admin with hasUnlimitedAccess -> skip charge entirely.
 *   2. Otherwise -> attempt atomic deduction BEFORE calling the model.
 *      If it fails (insufficient credits), surface the paywall and never call the model.
 */
class CreditViewModel(
    private val repo: FirestoreRepository = FirestoreRepository()
) : ViewModel() {

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _events = MutableSharedFlow<AiQueryEvent>()
    val events = _events.asSharedFlow()

    /**
     * @param onAuthorized called once credit is confirmed available/deducted; do the actual
     *        model call inside this lambda.
     */
    fun runAiQuery(
        user: AppUser,
        modelUsed: String,
        creditCost: Long = 1L,
        onAuthorized: suspend () -> Unit
    ) {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                if (user.canUseAiWithoutCharge()) {
                    onAuthorized()
                    return@launch
                }
                repo.deductCredit(user.uid, creditCost, modelUsed)
                    .onSuccess { onAuthorized() }
                    .onFailure { err ->
                        if (err.message == "INSUFFICIENT_CREDITS") {
                            _events.emit(AiQueryEvent.ShowPaywall)
                        } else {
                            _events.emit(AiQueryEvent.Error(err.message ?: "Unknown error"))
                        }
                    }
            } finally {
                _isProcessing.value = false
            }
        }
    }
}
