package com.aiassistant.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aiassistant.app.model.UserRole
import com.aiassistant.app.ui.screens.AdminPanelScreen
import com.aiassistant.app.ui.screens.PaywallScreen
import com.aiassistant.app.ui.screens.SettingsScreen
import com.aiassistant.app.viewmodel.AuthUiState
import com.aiassistant.app.viewmodel.AuthViewModel

object Routes {
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val ADMIN_PANEL = "admin_panel"
    const val PAYWALL = "paywall"
    const val LOGIN = "login"
}

@Composable
fun AppNavigation(
    navController: NavHostController = rememberNavController(),
    authViewModel: AuthViewModel
) {
    val authState by authViewModel.uiState.collectAsState()

    NavHost(navController = navController, startDestination = Routes.LOGIN) {

        composable(Routes.SETTINGS) {
            val state = authState
            if (state is AuthUiState.LoggedIn) {
                SettingsScreen(
                    user = state.user,
                    onBuyCreditsClick = { navController.navigate(Routes.PAYWALL) },
                    onUpgradePlanClick = { navController.navigate(Routes.PAYWALL) },
                    onOpenAdminPanel = {
                        // Hard gate: even though the Settings UI only *shows* this button to
                        // admins, we re-check the role again right before navigating, since the
                        // button's visibility alone is not a security boundary.
                        if (state.user.role == UserRole.ADMIN) {
                            navController.navigate(Routes.ADMIN_PANEL)
                        }
                    },
                    onSetPersonalApiKey = { /* call FirestoreRepository update */ },
                    onClearChatHistory = { /* call chat history repo clear */ },
                    onSignOut = {
                        authViewModel.signOut()
                        navController.navigate(Routes.LOGIN) {
                            popUpTo(0)
                        }
                    }
                )
            }
        }

        composable(Routes.ADMIN_PANEL) {
            val state = authState
            // Route-level gate. If a non-admin session somehow lands here (deep link, restored
            // back-stack, etc.) we bounce them out instead of trusting arguments passed in.
            if (state is AuthUiState.LoggedIn && state.user.role == UserRole.ADMIN) {
                AdminPanelScreen(adminUid = state.user.uid)
            } else {
                UnauthorizedScreen(onBack = { navController.popBackStack() })
            }
        }

        composable(Routes.PAYWALL) {
            PaywallScreen(onClose = { navController.popBackStack() })
        }

        // composable(Routes.LOGIN) { LoginScreen(...) }
        // composable(Routes.CHAT) { ChatScreen(...) }
    }
}

@Composable
private fun UnauthorizedScreen(onBack: () -> Unit) {
    androidx.compose.material3.Text("You do not have permission to view this page.")
}
