package com.aiassistant.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiassistant.app.data.FirestoreRepository
import com.aiassistant.app.model.ApiKeyConfig
import com.aiassistant.app.model.AppUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Every method here assumes the CALLER has already been confirmed as ADMIN via AppUser.role.
 * That check must happen at the navigation layer (see AppNavigation.kt) AND is re-enforced by
 * Firestore security rules, so a compromised client still can't write these fields.
 */
class AdminViewModel(
    private val repo: FirestoreRepository = FirestoreRepository()
) : ViewModel() {

    private val _users = MutableStateFlow<List<AppUser>>(emptyList())
    val users: StateFlow<List<AppUser>> = _users.asStateFlow()

    private val _apiConfig = MutableStateFlow(ApiKeyConfig())
    val apiConfig: StateFlow<ApiKeyConfig> = _apiConfig.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun loadDashboard() {
        viewModelScope.launch {
            _users.value = repo.getAllUsers()
            _apiConfig.value = repo.getApiKeyConfig()
        }
    }

    fun setUserBalance(adminUid: String, targetUid: String, newBalance: Long) {
        viewModelScope.launch {
            repo.adminSetCreditBalance(targetUid, newBalance, adminUid)
                .onSuccess { _statusMessage.value = "Balance updated"; loadDashboard() }
                .onFailure { _statusMessage.value = "Failed: ${it.message}" }
        }
    }

    fun toggleUnlimited(targetUid: String, enabled: Boolean) {
        viewModelScope.launch {
            repo.adminGrantUnlimitedToggle(targetUid, enabled)
                .onSuccess { loadDashboard() }
                .onFailure { _statusMessage.value = "Failed: ${it.message}" }
        }
    }

    fun saveApiConfig(config: ApiKeyConfig) {
        viewModelScope.launch {
            repo.updateApiKeyConfig(config)
                .onSuccess { _statusMessage.value = "API config saved" }
                .onFailure { _statusMessage.value = "Failed: ${it.message}" }
        }
    }
}
