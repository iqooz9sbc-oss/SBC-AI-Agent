package com.aiassistant.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiassistant.app.data.AuthRepository
import com.aiassistant.app.data.FirestoreRepository
import com.aiassistant.app.model.AppUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Loading : AuthUiState()
    object LoggedOut : AuthUiState()
    data class LoggedIn(val user: AppUser) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(
    private val authRepo: AuthRepository = AuthRepository(),
    private val firestoreRepo: FirestoreRepository = FirestoreRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Loading)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        val fbUser = authRepo.currentFirebaseUser
        if (fbUser == null) {
            _uiState.value = AuthUiState.LoggedOut
        } else {
            listenToUser(fbUser.uid)
        }
    }

    fun login(email: String, password: String) {
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            authRepo.signInWithEmail(email, password)
                .onSuccess { listenToUser(it.uid) }
                .onFailure { _uiState.value = AuthUiState.Error(it.message ?: "Login failed") }
        }
    }

    fun register(email: String, password: String, displayName: String) {
        _uiState.value = AuthUiState.Loading
        viewModelScope.launch {
            authRepo.registerWithEmail(email, password, displayName)
                .onSuccess { listenToUser(it.uid) }
                .onFailure { _uiState.value = AuthUiState.Error(it.message ?: "Registration failed") }
        }
    }

    fun signOut() {
        authRepo.signOut()
        _uiState.value = AuthUiState.LoggedOut
    }

    /** Live-listens to the Firestore profile so role/credit changes (e.g. admin edits) reflect instantly. */
    private fun listenToUser(uid: String) {
        firestoreRepo.observeUser(uid) { user ->
            _uiState.value = if (user != null) AuthUiState.LoggedIn(user) else AuthUiState.LoggedOut
        }
    }
}
