package com.aiassistant.app.data

import com.aiassistant.app.model.AppUser
import com.aiassistant.app.model.ApiKeyConfig
import com.aiassistant.app.model.UserRole
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class FirestoreRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val usersCol get() = db.collection("users")
    private val configDoc get() = db.collection("config").document("apiKeys")

    fun observeUser(uid: String, onChange: (AppUser?) -> Unit) =
        usersCol.document(uid).addSnapshotListener { snap, _ ->
            onChange(snap?.toObject(AppUser::class.java))
        }

    /**
     * Atomically deducts credit for one AI call. Uses a Firestore transaction so concurrent
     * requests can't push balance negative. Admins with hasUnlimitedAccess never reach this path
     * — callers must check `user.canUseAiWithoutCharge()` first and skip the deduction entirely.
     */
    suspend fun deductCredit(uid: String, amount: Long = 1L, modelUsed: String): Result<Long> = runCatching {
        db.runTransaction { txn ->
            val ref = usersCol.document(uid)
            val snap = txn.get(ref)
            val role = UserRole.fromString(snap.getString("role"))
            val unlimited = snap.getBoolean("hasUnlimitedAccess") ?: false
            if (role == UserRole.ADMIN && unlimited) {
                return@runTransaction snap.getLong("creditBalance") ?: 0L
            }
            val current = snap.getLong("creditBalance") ?: 0L
            if (current < amount) error("INSUFFICIENT_CREDITS")
            val newBalance = current - amount
            txn.update(ref, "creditBalance", newBalance)
            newBalance
        }.await()
    }.also {
        if (it.isSuccess) logTransaction(uid, -amount, "AI_QUERY", modelUsed)
    }

    /** Called by the IAP purchase flow after Play Billing confirms + server verifies the receipt. */
    suspend fun addPurchasedCredits(uid: String, amount: Long, sku: String): Result<Unit> = runCatching {
        usersCol.document(uid).update("creditBalance", FieldValue.increment(amount)).await()
        logTransaction(uid, amount, "IAP_PURCHASE", sku)
    }

    private suspend fun logTransaction(uid: String, amount: Long, reason: String, related: String?) {
        usersCol.document(uid).collection("transactions").add(
            mapOf(
                "uid" to uid,
                "amount" to amount,
                "reason" to reason,
                "relatedModel" to related,
                "timestamp" to System.currentTimeMillis()
            )
        ).await()
    }

    // ---------------- ADMIN-ONLY QUERIES (rules also enforce this server-side) ----------------

    suspend fun getAllUsers(limit: Long = 100): List<AppUser> =
        usersCol.orderBy("createdAt").limitToLast(limit).get().await()
            .documents.mapNotNull { it.toObject(AppUser::class.java) }

    /** Admin manually sets a user's balance — e.g. support/refund case. Rules require caller role == ADMIN. */
    suspend fun adminSetCreditBalance(targetUid: String, newBalance: Long, adminUid: String): Result<Unit> =
        runCatching {
            usersCol.document(targetUid).update("creditBalance", newBalance).await()
            logTransaction(targetUid, newBalance, "ADMIN_GRANT", "set_by:$adminUid")
        }

    suspend fun adminGrantUnlimitedToggle(targetUid: String, enabled: Boolean): Result<Unit> = runCatching {
        usersCol.document(targetUid).update("hasUnlimitedAccess", enabled).await()
    }

    suspend fun getApiKeyConfig(): ApiKeyConfig =
        configDoc.get().await().toObject(ApiKeyConfig::class.java) ?: ApiKeyConfig()

    suspend fun updateApiKeyConfig(config: ApiKeyConfig): Result<Unit> = runCatching {
        configDoc.set(config).await()
    }
}
