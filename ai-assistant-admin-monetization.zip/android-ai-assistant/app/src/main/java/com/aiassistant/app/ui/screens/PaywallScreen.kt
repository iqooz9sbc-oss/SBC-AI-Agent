package com.aiassistant.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class CreditPack(val sku: String, val label: String, val credits: Int, val price: String)

private val creditPacks = listOf(
    CreditPack("credits_50", "Starter Pack", 50, "$0.99"),
    CreditPack("credits_150", "Value Pack", 150, "$2.49"),
    CreditPack("credits_500", "Power Pack", 500, "$6.99")
)

@Composable
fun PaywallScreen(
    onClose: () -> Unit,
    onBuyCreditPack: (String) -> Unit = {},
    onSubscribe: (String) -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("You're out of credits", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Buy a credit pack or subscribe for unlimited monthly usage.")

        creditPacks.forEach { pack ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(pack.label, fontWeight = FontWeight.SemiBold)
                        Text("${pack.credits} credits")
                    }
                    Button(onClick = { onBuyCreditPack(pack.sku) }) { Text(pack.price) }
                }
            }
        }

        Divider()

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Pro Monthly — unlimited chat", fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { onSubscribe("pro_monthly") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Subscribe") }
            }
        }

        TextButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Not now") }
    }
}
