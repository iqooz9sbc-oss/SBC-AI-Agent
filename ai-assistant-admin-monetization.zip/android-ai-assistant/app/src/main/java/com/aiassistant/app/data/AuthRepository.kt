package com.aiassistant.app.data

import com.aiassistant.app.model.AppUser
import com.aiassistant.app.model.UserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * IMPORTANT SECURITY NOTE:
 * The "master admin" email below only decides who a Cloud Function is willing to promote to
 * ADMIN. It must NEVER be trusted client-side as proof of admin status by itself — always read
 * `role` back from Firestore (which is locked down by security rules so only Cloud Functions /
 * existing admins can write it). Hardcoding a "you're admin because your email matches" check in
 * Kotlin is not real security since APKs can be decompiled; treat this constant as a UX hint only.
 */
object AdminConfig {
    const val MASTER_ADMIN_EMAIL = "owner@yourdomain.com" // change before shipping
}

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    val currentFirebaseUser: FirebaseUser? get() = auth.currentUser

    suspend fun signInWithEmail(email: String, password: String): Result<AppUser> = runCatching {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        val fbUser = result.user ?: error("Sign-in failed: no user returned")
        fetchOrBootstrapUser(fbUser)
    }

    suspend fun registerWithEmail(email: String, password: String, displayName: String): Result<AppUser> =
        runCatching {
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            val fbUser = result.user ?: error("Registration failed: no user returned")
            bootstrapNewUser(fbUser, displayName)
        }

    suspend fun signInWithGoogleCredential(credential: com.google.firebase.auth.AuthCredential): Result<AppUser> =
        runCatching {
            val result = auth.signInWithCredential(credential).await()
            val fbUser = result.user ?: error("Google sign-in failed")
            fetchOrBootstrapUser(fbUser)
        }

    fun signOut() = auth.signOut()

    /** Called after login: pulls the Firestore profile, which is the ONLY trusted source of role. */
    private suspend fun fetchOrBootstrapUser(fbUser: FirebaseUser): AppUser {
        val docRef = db.collection("users").document(fbUser.uid)
        val snapshot = docRef.get().await()
        return if (snapshot.exists()) {
            snapshot.toAppUser(fbUser)
        } else {
            bootstrapNewUser(fbUser, fbUser.displayName ?: "")
        }
    }

    /**
     * Creates the Firestore profile for a brand-new user with the default USER role and a
     * welcome credit bonus. This write is allowed by security rules ONLY for the user's own uid
     * and ONLY with role == "USER" and a capped welcome amount — see firestore.rules.
     */
    private suspend fun bootstrapNewUser(fbUser: FirebaseUser, displayName: String): AppUser {
        val welcomeCredits = 10L
        val newUser = AppUser(
            uid = fbUser.uid,
            email = fbUser.email ?: "",
            displayName = displayName,
            role = UserRole.USER,
            creditBalance = welcomeCredits,
            hasUnlimitedAccess = false,
            subscriptionTier = "FREE"
        )
        db.collection("users").document(fbUser.uid).set(newUser).await()
        db.collection("users").document(fbUser.uid)
            .collection("transactions").add(
                mapOf(
                    "uid" to fbUser.uid,
                    "amount" to welcomeCredits,
                    "reason" to "WELCOME_BONUS",
                    "timestamp" to System.currentTimeMillis()
                )
            ).await()
        return newUser
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.toAppUser(fbUser: FirebaseUser): AppUser {
        return AppUser(
            uid = fbUser.uid,
            email = getString("email") ?: fbUser.email.orEmpty(),
            displayName = getString("displayName") ?: fbUser.displayName.orEmpty(),
            role = UserRole.fromString(getString("role")),
            creditBalance = getLong("creditBalance") ?: 0L,
            hasUnlimitedAccess = getBoolean("hasUnlimitedAccess") ?: false,
            subscriptionTier = getString("subscriptionTier") ?: "FREE",
            subscriptionExpiresAt = getLong("subscriptionExpiresAt"),
            personalApiKey = getString("personalApiKey")
        )
    }
}
