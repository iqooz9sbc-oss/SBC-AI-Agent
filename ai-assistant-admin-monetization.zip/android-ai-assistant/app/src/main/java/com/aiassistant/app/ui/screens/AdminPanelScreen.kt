package com.aiassistant.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiassistant.app.model.ApiKeyConfig
import com.aiassistant.app.model.AppUser
import com.aiassistant.app.viewmodel.AdminViewModel

/**
 * Gate this screen at the NAVIGATION level:
 *   if (currentUser.role != UserRole.ADMIN) navController.popBackStack()
 * Never rely on this composable alone to hide admin functionality — Firestore rules are the
 * real enforcement layer; this UI check only prevents an honest client from showing the screen.
 */
@Composable
fun AdminPanelScreen(
    adminUid: String,
    viewModel: AdminViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val users by viewModel.users.collectAsState()
    val apiConfig by viewModel.apiConfig.collectAsState()
    val status by viewModel.statusMessage.collectAsState()

    LaunchedEffect(Unit) { viewModel.loadDashboard() }

    var tab by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Users") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("API Config") })
        }

        status?.let {
            Text(it, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary)
        }

        when (tab) {
            0 -> UserManagementTab(users, adminUid, viewModel)
            1 -> ApiConfigTab(apiConfig, onSave = viewModel::saveApiConfig)
        }
    }
}

@Composable
private fun UserManagementTab(users: List<AppUser>, adminUid: String, viewModel: AdminViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(users, key = { it.uid }) { user ->
            UserRow(
                user = user,
                onBalanceChange = { newBalance -> viewModel.setUserBalance(adminUid, user.uid, newBalance) },
                onToggleUnlimited = { enabled -> viewModel.toggleUnlimited(user.uid, enabled) }
            )
        }
    }
}

@Composable
private fun UserRow(
    user: AppUser,
    onBalanceChange: (Long) -> Unit,
    onToggleUnlimited: (Boolean) -> Unit
) {
    var balanceText by remember(user.uid) { mutableStateOf(user.creditBalance.toString()) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(user.email, style = MaterialTheme.typography.titleSmall)
            Text("Role: ${user.role} · Tier: ${user.subscriptionTier}", style = MaterialTheme.typography.bodySmall)

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it.filter(Char::isDigit) },
                    label = { Text("Credits") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = { balanceText.toLongOrNull()?.let(onBalanceChange) }) {
                    Text("Set")
                }
            }

            if (user.role.name == "ADMIN") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Unlimited access", modifier = Modifier.weight(1f))
                    Switch(checked = user.hasUnlimitedAccess, onCheckedChange = onToggleUnlimited)
                }
            }
        }
    }
}

@Composable
private fun ApiConfigTab(config: ApiKeyConfig, onSave: (ApiKeyConfig) -> Unit) {
    var gemini by remember(config) { mutableStateOf(config.geminiKey) }
    var openRouter by remember(config) { mutableStateOf(config.openRouterKey) }
    var groq by remember(config) { mutableStateOf(config.groqKey) }
    var ollama by remember(config) { mutableStateOf(config.ollamaEndpoint) }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Global Fallback API Keys", style = MaterialTheme.typography.titleMedium)
        Text(
            "These keys are used when a user has no personal API key set and are stored in " +
                "config/apiKeys, readable only by Cloud Functions / backend — never shipped to " +
                "user devices in plaintext. Consider a backend proxy instead of storing raw keys " +
                "in Firestore for production.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(gemini, { gemini = it }, label = { Text("Gemini API Key") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(openRouter, { openRouter = it }, label = { Text("OpenRouter API Key") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(groq, { groq = it }, label = { Text("Groq API Key") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ollama, { ollama = it }, label = { Text("Ollama Endpoint URL") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                onSave(
                    ApiKeyConfig(
                        geminiKey = gemini,
                        openRouterKey = openRouter,
                        groqKey = groq,
                        ollamaEndpoint = ollama
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save Configuration") }
    }
}
